Hello There,
 Please Follow Instructions To Install the software 

  - Please stop the antivirus / firewall / windows defender as they sometime block the crack 

 - Simply extract the zip file (use winrar, its recommended) 

 - Check password in Password.txt file 

 - Run setup_install.exe 

 Enjoy!